<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*************
* English Language file for Dispute
***************************/

$lang['dispute_meta_title'] = 'Dispute Center';
$lang['dispute_center_well_header_h5'] = 'Dispute center';
$lang['dipute_claim_failed'] = 'Dispute failed to sent.';
$lang['dipute_claim_success'] = 'Dispute is success sent, to receiver and our support we looking on it.';
$lang['dispute_refund_failed'] = 'Dispute is faild to refund the payment';
$lang['dispute_refund_success'] = 'Dispute is solved and the payment is return to sender.';