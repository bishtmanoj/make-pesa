<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*************
* English Language file for Welcome Page
***************************/
$lang['Deposit_sms_subject_hello'] = 'Hello!';
$lang['Deposit_sms_subject_have'] = 'You have Deposit';
$lang['Deposit_sms_subject_to_wallet'] = 'to your wallet, Login here https://yoursite.com to see your balance.';
$lang['Deposit_sms_subject_to_wallet_a'] = 'to your Wallet, ';
$lang['Deposit_sms_subject_with_method'] = 'With';
$lang['Deposit_sms_subject_link_go'] = 'Login here https://yoursite.com to see your Balance.';
$lang['not_login'] = 'Sorry please login';