<footer class="footer">

  <div class="navft">
    <div class="top-navft">
      <ul class="top-left-navft">
        <a href="#"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
        <a href="<?php echo site_url().'page/help/'; ?>"><li>Help & Contact</li></a>
        <a href="<?php echo site_url().'page/fees/'; ?>"><li>Fees</li></a>
        <a href="#"><li>Security</li></a>
        <a href="#"><li>Apps</li></a>
        <a href="#"><li>Shop</li></a>
      </ul>

      <a href="#" data-toggle="modal" data-target="#languagepicker"><div class="country">
	  </div></a>
    </div>
    
    <div class="btm-navft">
      <ul class="btm-left-navft">
        <a href="#"><li>About</li></a>
        <a href="#"><li>Blog</li></a>
        <a href="#"><li>Jobs</li></a>
        <a href="#"><li>User Agreement</li></a>
        <a href="#"><li>Public Policy</li></a>
        <a href="#"><li>Sitemap</li></a>
        <a href="<?php echo site_url().'page/developer'; ?>"><li>Developer</li></a>
      </ul>
      
      <ul class="btm-right-navft">
        <span>&copy; 2013 - <?php echo date("Y"); ?></span>
        <a href="#"><li>Privacy</li></a>
        <a href="#"><li>Legal</li></a>
        <a href="#"><li>Feedback</li></a>
      </ul>
    </div>
    
  </div>
  </div>
  
</footer>