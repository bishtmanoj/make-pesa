		<div class="settings-payments">
		
		<h4>
		<?php echo $this->lang->line('settings_payments_instore_h4_head'); ?>
		</h4>
		<p>
		<?php echo $this->lang->line('settings_payments_instore_p_when_head'); ?>
		</p>
		<div class="settings-payments-instore">
		<h5>
		<?php echo $this->lang->line('settings_payments_instore_h5_expand'); ?>
		<a href="#" class="pull-right" data-toggle="collapse" data-target="#instore" aria-expanded="false" aria-controls="instore">
		<?php echo $this->lang->line('settings_payments_instore_h5_expand_link'); ?>
		</a>
		</h5>
		
		<div id="instore" class="panel-collapse collapse">
		<?php echo $this->lang->line('settings_payments_instore_h5_expand_pay_notes'); ?>
		</div>
		</div>
		</p>
		</div>