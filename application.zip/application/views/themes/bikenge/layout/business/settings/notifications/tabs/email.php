		<div class="settings-payments">
		<?php echo $this->lang->line('settings_payments_notifications_notes'); ?>
		</div>