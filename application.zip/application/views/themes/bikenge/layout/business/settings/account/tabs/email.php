		<div class="well">
		<h4>
		<?php echo $this->lang->line('settings_account_update_email_well_header_h4'); ?>
		</h4>
		
		<ul class="nav">
		<li>
		<h5><?php echo $this->user->email; ?></h5>
		</li>
		<li>
		<p>
		<?php echo $this->lang->line('settings_account_update_email_well_p_default'); ?>
		</p>
		</li>
		</ul>
		</div>