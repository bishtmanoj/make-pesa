      <div class="container-fluid">
      <div class="row">
      <div class="col-sm-15 col-md-15 col-md-offset-0">
		<!-- nav -->
		<?php $this->load->view($this->themename.'/layout/business/settings/nav/nav-settings'); ?>
		
		<!-- End nav -->
        <div class="col-sm-12 col-md-12">
		
		<!-- Payments tabs -->
		<div class="well">
		<!-- PIN -->
		<?php $this->load->view($this->themename.'/layout/business/settings/notifications/tabs/email'); ?>
		<!-- End PIN -->
		
		</div>
		
		<!-- End payments tabs -->
	
		  </div><!--/span-->
		  </div><!--/span-->
      </div><!--/row-->
    </div><!--/.container-->
	