		<div class="settings-security">
		<a href="#" aria-hidden="true" data-toggle="modal" data-target="#security-password">
		
		
		<ul class="nav">
		<li>
		<h4>
		<?php echo $this->lang->line('settings_security_well_header_h4_password'); ?>
		<i class="fa fa-pencil-square-o fa-lg pull-right"></i>
		</h4>
		</li>
		<li>
		<p>
		<?php echo $this->lang->line('settings_security_update_password_p'); ?>
		</p>
		</li>
		</ul>
		</a>
		</div>
		