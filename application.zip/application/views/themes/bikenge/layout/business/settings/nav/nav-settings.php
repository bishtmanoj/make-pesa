		<ul class="nav settings-nav">
		<li><a href="<?php echo site_url().'business/settings/account/'; ?>">Account</a></li>
		<li><a href="<?php echo site_url().'business/settings/security/'; ?>">Security</a></li>
		<li><a href="<?php echo site_url().'business/settings/payments/'; ?>">Payments</a></li>
		<li><a href="<?php echo site_url().'business/settings/notifications/'; ?>">Notifications</a></li>
		</ul>