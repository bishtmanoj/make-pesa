		<div class="settings-security">
		<a href="#" aria-hidden="true" data-toggle="modal" data-target="#security-pin">
		
		
		<ul class="nav">
		<li>
		<h4>
		<?php echo $this->lang->line('settings_security_well_header_h4_pin'); ?>
		<i class="fa fa-pencil-square-o fa-lg pull-right"></i>
		</h4>
		</li>
		<li>
		</li>
		</ul>
		</a>
		</div>