	 <div class="head-padding-top"></div>
	 <div class="container">
	 <div class="row">
	 <div class="col-sm-13 col-sm-offset-2 col-md-13 col-md-offset-0">
	 <div class="row">

        <div class="col-sm-4 col-md-4">
		 <?php $this->load->view($this->themename.'/layout/admin/globe/sidebar/nav'); ?>
            </div>
			
			
	<div class="col-sm-8 col-md-8">
		<?php $this->load->view($this->themename.'/layout/admin/transaction/method/withdraw/form'); ?>	
	 </div><!-- span-->
	 
	 </div><!-- span-->
      </div><!-- span-->
	  </div><!-- row-->
	  </div><!-- container-->
