		<ul class="nav settings-nav">
		<li><a href="<?php echo site_url().'myaccount/settings/account/'; ?>">Account</a></li>
		<li><a href="<?php echo site_url().'myaccount/settings/security/'; ?>">Security</a></li>
		<li><a href="<?php echo site_url().'myaccount/settings/payments/'; ?>">Payments</a></li>
		<li><a href="<?php echo site_url().'myaccount/settings/notifications/'; ?>">Notifications</a></li>
		</ul>