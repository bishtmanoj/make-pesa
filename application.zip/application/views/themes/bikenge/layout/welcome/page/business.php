<!-- Welcome cover -->
<div class="welcome-cover-no-image">
  <h2>
  <?php echo $this->lang->line('welcome_page_business_cover_no_image_h2');?>
  </h2>
  <p>
  <?php echo $this->lang->line('welcome_page_business_cover_no_image_p');?>
  </p>


</div>

  <div class="container">

  <div class="col-md-12  col-md-12">
  <div class="welcome-home-document-merchant">
  <h1>
  <?php echo $this->lang->line('welcome_page_business_signup_h1_note');?> 
  <a href="<?php echo site_url().'signup/business/start'; ?>">
  <?php echo $this->lang->line('welcome_page_business_signup_h1_note_button');?>
  </a>
  </h1>
  </div>
  </div>
  
  </div>
</div>