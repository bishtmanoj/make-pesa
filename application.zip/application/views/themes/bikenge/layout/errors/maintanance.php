<div class="head-padding-top"></div>
<div class="container">
<div class="row">
<div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
<div class="box-signup-choose">
<div class="well">
         <div class="well-header">
               <center>
			   <i class="fa fa-paint-brush fa-3x" aria-hidden="true"></i>
			   </center>
               <h4 class="text-center"><?php echo $this->lang->line('maintanance_error_h2_desc');?></h4>
			   <hr>
            </div>
      </div>
	  </div>
      </div><!-- span-->
	  </div><!-- row-->
	  </div><!-- container-->
