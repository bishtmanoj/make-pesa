<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-04 18:14:34 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-04 18:14:34 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-04 23:08:50 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-04 23:08:50 --> Could not find the language line "welcome_home_navbar_right_create_account"
