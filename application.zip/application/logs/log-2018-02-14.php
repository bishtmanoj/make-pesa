<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-14 13:45:39 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-14 13:45:39 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-14 13:45:58 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-14 13:45:58 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-14 13:46:12 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-14 13:46:12 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-14 13:46:23 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-14 13:46:23 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-14 15:16:31 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-14 15:16:31 --> Could not find the language line "welcome_home_navbar_right_create_account"
