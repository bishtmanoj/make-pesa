<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-16 07:50:11 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-16 07:50:11 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-16 08:42:03 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-16 08:42:03 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-16 09:06:06 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-16 09:06:06 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-16 09:09:42 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-16 09:09:42 --> Could not find the language line "welcome_home_navbar_right_create_account"
