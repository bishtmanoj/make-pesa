<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-01 12:35:55 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-01 12:35:55 --> Could not find the language line "welcome_home_navbar_right_create_account"
ERROR - 2018-02-01 19:07:13 --> Could not find the language line "welcome_home_navbar_right_my_account"
ERROR - 2018-02-01 19:07:13 --> Could not find the language line "welcome_home_navbar_right_create_account"
